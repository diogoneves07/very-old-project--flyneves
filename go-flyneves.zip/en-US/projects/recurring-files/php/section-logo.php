<article class="section-in-highlight">
        <header>
            <h1>
            Developed projects
            </h1>
        </header>
        <p>
        Discover our project inventory: libraries, algorithms and others.
    </p>
        <section class="section-in-highlight-other">
        <nav class="projects-list">
                <ul class="projects-list-links">
                    <li title="JavaScript library - textFieldRangeJS">
                        <a href="../projects/textFieldRangeJS/">
                        <img  src="recurring-files/icons-projects/textFieldRange-small-logo-black.png" alt="JavaScript library - textFieldRangeJS" class="visible-in-light-theme textFieldRange-icon"  />
                        <img  src="recurring-files/icons-projects/textFieldRange-small-logo-white.png" alt="JavaScript library - textFieldRangeJS" class="visible-in-dark-theme textFieldRange-icon"  />
                        </a>
                    </li>
                    <li title="JavaScript library - controlAnimationJS">
                        <a href="../projects/controlAnimationJS/">
                        <img  src="recurring-files/icons-projects/controlAnimation-normal-logo-black.png" alt="JavaScript library - controlAnimationJS" class="visible-in-light-theme controlAnimation-icon"  />
                        <img  src="recurring-files/icons-projects/controlAnimation-normal-logo-white.png" alt="JavaScript library - controlAnimationJS" class="visible-in-dark-theme controlAnimation-icon"  />
                        </a>
                    </li>
                </ul>
            </nav>
        </section>
</article>
                   