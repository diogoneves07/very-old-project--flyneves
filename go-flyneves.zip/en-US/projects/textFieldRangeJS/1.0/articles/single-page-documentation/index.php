<article class="important-content-section">
    <header>
        <h1>
        Single page documentation
        </h1>
    </header>
    <p>
    This page contains all the documentation textFieldRangeJS library.
    </p>
</article>
