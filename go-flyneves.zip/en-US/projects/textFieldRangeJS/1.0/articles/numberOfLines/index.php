<article class="important-content-section">
    <header>
        <h1>
            numberOfLines property
        </h1>
    </header>
    <p>
    The number of lines contained in the text field.
    </p>
    <h2 class="subtitles-main">
        <span>
            Detail
        </span>
    </h2>
    <p>
        This is a read-only property, that is, its value must not be changed.
    </p>
    <h2 class="subtitles-main">
        <span>
            Syntax
        </span>
    </h2>
    <div class="code-example">
        <pre><code>
            var numberOfLines = textFieldRange( element ).numberOfLines;
        </code></pre>
    </div>
    <h2 class="subtitles-main">
        <span>
            Browser Support
        </span>
    </h2>
    <p>This property has the same compatibility table as the library, that is, just look at the library support table.</p>
</article>
