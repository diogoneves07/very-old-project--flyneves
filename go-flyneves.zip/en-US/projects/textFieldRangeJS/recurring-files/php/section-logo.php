<div class="section-in-highlight">
        <header>
        <img src="<?php echo $pathToSiteDirectories->sectionDirectory; ?>textFieldRange-small-logo-black.png" class="project-logo visible-in-light-theme" alt="textFieldRangeJS - logo"/>
        <img src="<?php echo $pathToSiteDirectories->sectionDirectory; ?>textFieldRange-small-logo-white.png" class="project-logo visible-in-dark-theme" alt="textFieldRangeJS - logo"/>
        </header>
        <p>
        Simple, useful, light and complete, aimed at controlling and obtaining data from HTML elements of text entry.</p>
        <section class="section-in-highlight-other">
        <nav class="library-start-links">
            <ul>
                <li>
                <a href="../">
                Projects
                    </a>
                </li>
                <li>
                <a href="https://www.github.com/diogoneves07/textFieldRangeJS/" target="_blank">
                GitHub
                </a>
                </li>
            </ul>
        </nav>
        </section>
</div>
                   
                   