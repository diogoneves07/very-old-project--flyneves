<article class="important-content-section">
    <header>
        <h1>
        Versions 
        </h1>
    </header>
    <p>
    On this page, you will find links to all versions of the controlAnimationJS library.
   </p>
    </p>
    <nav class="documentation-links">
        <ul class="normal-list">
            <li>
                <a href="1.0/">
                controlAnimation – 1.0
                </a>
            </li>
        </ul>
    </nav>
</article>
