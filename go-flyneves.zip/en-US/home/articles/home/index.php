<article class="important-content-section">
    <header>
        <h1>
        Welcome developer
        </h1>
    </header>
    <p>
    FlyNeves is a recently launched website, with the objective of developing open source <a href="projects/"><strong>projects</strong></a> for different technologies, with the motto: learn, develop and share, because programming is also fun.
    </p>
    <div class="home-image-text-2">
        <span>$</span>
        <p>
        At no time do our projects aim at profit. We like to innovate, develop, help those who helped us, because during our careers at some point we use some free tool.
        </p>
    </div>
    <div class="home-image-text-3">
        <span>                        
            <img src="../building-construction.png" />
        </span>
        <p>
        We are under construction. Everything related to the website and the projects was developed by a single developer.        </p>
        <p>
        Like or participate in our social pages, this incentive us to maintain this site.
        </p>
    </div>
   
</article>