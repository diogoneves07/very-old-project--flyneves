<aside class="important-content-section">
        <section>
        <h2 class="subtitles-main">
        <span>
            How to contribute?
            </span>
        </h2>
        <p>
        Hello developer, my name is Diogo Neves, Currently this site does not have an involvement platform, but, you can contact me: <a href="https://www.github.com/diogoneves07" target="_blank"> Diogo Neves - GitHub</a>.
        </p>
    </section>
</aside>