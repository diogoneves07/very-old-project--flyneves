<header id="header-main">
    <div class="logo">
        <div>
            <strong>
                <a href="https://www.FlyNeves.com/pt-BR/">
                    FlyNeves.com
                </a>
            </strong>
        </div>
    </div>
    <nav class="main-navigation-buttons" >
        <div class="main-navigation-buttons-fixed">
            <div class="buttons-main">
                <button class="menu-button">
                    <div>
                        <span></span>
                    </div>
                </button>
                <button class="search-button ">
                    <span class="search-button-span-1"></span>
                    <span class="search-button-span-2"></span>
                </button>
                <button class="warning-button">
                    <div>
                        <span>
                            !
                        </span>
                    </div>
                </button>
            </div>
        </div>
    </nav>
</header>