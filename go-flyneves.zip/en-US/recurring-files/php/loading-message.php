<div class="loading-message">
    <div>
        <img src="<?php echo $pathToSiteDirectories->rootDirectory ?>FlyNeves-logo-black.png" class="FlyNeves-logo-black" />
        <img src="<?php echo $pathToSiteDirectories->rootDirectory ?>FlyNeves-logo-white.png" class="FlyNeves-logo-white" />
        <span>Loading...</span>
        <noscript>
            <hr style="float:left;width:80%;margin:0 10%;position:relative;top:-40px;"/>
            <strong style="float:left;width:80%;margin:20px 10%;">
            Is required enable JavaScript and refresh the page.
            </strong>
        </noscript>
    </div>
</div>