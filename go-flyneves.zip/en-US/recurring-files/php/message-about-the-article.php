<aside class="important-content-section">
        <section>
            <h2 class="subtitles-main">
                <span>
                    Dúvidas, críticas, elogios?
                </span>
            </h2>
            <p>
                Olá desenvolvedor, caso tenha alguma dúvida ou não tenha gostando da maneira quê a documentação da biblioteca Esta descrita ou melhor ainda tenha algum elogio em relação a bliblioteca ou a outros projetos, sinta-se a vontade
                para mandar mensagens em minhas redes sociais. Agradeço muito a sua visita a esta página.
            </p>
        </section>
    </aside>