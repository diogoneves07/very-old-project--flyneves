<div class="main-menu-platforms menu" >
    <header class="content-hidden-titles">
        <h4>
            <span>
            Social pages
            </span>
        </h4>
    </header> 
    <nav>
        <ul>
        <li>
        <a href="https://www.github.com/flyneves" target="_blank">
            GitHub 
            </a>
        </li>
        <li> 
            <a href="https://www.twitter.com/fly_neves" target="_blank">
            Twitter 
            </a> 
        </li>
        </ul>
    </nav>
</div>