<!-- ICON MAC -->
<link rel="apple-touch-icon" href="https://www.flyneves.com/favicon.png">
<meta name="apple-mobile-web-app-title" content="FlyNeves">
<link rel="shortcut icon" href="<?php echo $pathToSiteDirectories->rootDirectory; ?>favicon.png">
<!-- FAVICON HTML5-->
<link rel="icon" href="<?php echo $pathToSiteDirectories->rootDirectory; ?>favicon.png">
<!-- FAVICON IE-->
<link rel="icon" type="image/png" href="<?php echo $pathToSiteDirectories->rootDirectory; ?>favicon.png">
<!-- Others -->
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="copyright" content="© 2020 FlyNeves" />
<meta name="rating" content="general" />

