<aside class="fixed-tools">
    <section class="fixed-tools-container">
        <nav>
            <header>
                <span>
                Go to the section...
                </span>  
            </header>
            <ul>
                <li class="anchor-link-style-button"><a href="#">Beginning &uarr;</a></li>
                <li class="anchor-link-style-button"><a href="#footer-main">Footer &darr;</a></li>

            </ul> 
        </nav>
    </section>
    <button class="fixed-tools-button button-links-anchors">
    <strong>Anchors</strong>
        <div class="icon-open-book-in-html-medium book-one-page">
            <div class="icon-open-book-in-html-medium-div-1">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="icon-open-book-in-html-medium-div-2 book-two-pages-span-1">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </button>
    
</aside>
<p class="cookie-use-message">This website uses cookies to improve your experience. Learn more in <a href="<?php echo $pathToSiteDirectories->rootDirectory; ?>politica-de-privacidade/" target="_blank"> privacy policy</a>.<button id="cookie-use-message-button">Ok</button></p>