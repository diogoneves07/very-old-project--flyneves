<aside class="important-content-section-aside">
        <section>
            <header>
                <h2>
                    Plataformas
                </h2>
            </header>
            <nav>
                <ul>
                    <li>
                        <a href="documentfação/"> Propriedade </a>
                    </li>
                    <li>
                        <a href="documentacao/f/"> Método </a>
                    </li>
                    <li>
                        <a href="documentacao/f/"> Propriedade </a>
                    </li>
                </ul>
            </nav>
        </section>
    </aside>