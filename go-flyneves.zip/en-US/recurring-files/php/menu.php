<div class="main-menu menu">
    <div class="main-menu-div">
        <header class="content-hidden-titles">
            <h4>
                <span>
                Site
                </span>
            </h4>
        </header> 
        <nav class="main-menu-nav">
            <ul>
                <li>
                    <a href="<?php echo $pathToSiteDirectories->languageDirectory; ?>">
                    Home
                    </a>
                </li>
               
                <li>
                    <a href="<?php echo $pathToSiteDirectories->languageDirectory; ?>projects/">
                    Projects
                    </a> 
                </li>  
                <li>
                <a href="https://www.github.com/diogoneves07" target="_blank">                    Talk to the developer
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>