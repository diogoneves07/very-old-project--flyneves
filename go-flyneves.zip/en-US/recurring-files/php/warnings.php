<div class="warnings">
    <div class="warnings-list">
        <div>
            <header class="content-hidden-titles">
                <h4>
                    <span>
                    Warnings  
                    </span>
                </h4>
            </header> 
            <span class="no-warnings-message">
            There are currently no warnings; Remember to follow our pages on social networks, there you will always be informed about our projects.            </span>
        </div>
    </div>
</div>