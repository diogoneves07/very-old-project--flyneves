<div class="warnings">
    <div class="main-menu">
        <div class="main-menu-div">
            <header class="content-hidden-titles">
                <h4>
                    <span>
                    Warning levels
                    </span>
                </h4>
            </header> 
            <nav class="main-menu-nav">
                <ul>
                    <li>
                        <a>
                            N1: Normal
                        </a>
                    </li>  
                    <li>
                        <a>
                            N2: Attention 
                        </a>
                    </li> 
                    <li>
                        <a>
                            N3: Urgent
                        </a> 
                    </li>     
                </ul>
            </nav>
        </div>
    </div>
</div>