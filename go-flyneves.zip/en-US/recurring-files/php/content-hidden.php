<div class="content-hidden">
    <?php 
        include($pathToSiteDirectories->easyPathToDirectory->php."search.php");
    ?>
    <div class="content-hidden-left">
    <?php 
        include($pathToSiteDirectories->easyPathToDirectory->php."menu.php");
        include($pathToSiteDirectories->easyPathToDirectory->php."warnings-level.php");
    ?>
    </div>
    <div class="content-hidden-right">
    <?php 
        include($pathToSiteDirectories->easyPathToDirectory->php."menu-platforms.php");
        include($pathToSiteDirectories->easyPathToDirectory->php."warnings.php");
    ?>
    </div>
    <div class="close-content-hidden">
        <button>
        Close
        </button>
    </div>
</div>
