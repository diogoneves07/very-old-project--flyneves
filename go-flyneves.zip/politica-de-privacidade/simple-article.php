<div class="loading-message">
    <div>
        <img src="<?php echo $pathToSiteDirectories->rootDirectory ?>FlyNeves-logo-black.png" class="FlyNeves-logo-black" />
        <img src="<?php echo $pathToSiteDirectories->rootDirectory ?>FlyNeves-logo-white.png" class="FlyNeves-logo-white" />
    </div>
</div>