<div class="section-in-highlight">
    <header class="project-logo flyNeves-logo-presentation">
        <div class="lost-on-the-site">
        <img src="<?php echo $pathToSiteDirectories->rootDirectory; ?>FlyNeves-logo-white.png" class="visible-in-dark-theme" alt="FlyNeves - logo" title="FlyNeves - logo" />
        <img src="<?php echo $pathToSiteDirectories->rootDirectory; ?>FlyNeves-logo-black.png" class="visible-in-light-theme" alt="FlyNeves - logo" title="FlyNeves - logo" />
            <p>
                <span>?</span>
                Desculpe, a página solicitada não foi encontrada: <strong>404</strong>.
            </p>
        </div>
    </header>
    <section class="section-in-highlight-other">
        <div class="button-go-home">
        <a href="../">HOME</a>
        </div>
    </section>
</div>
                   