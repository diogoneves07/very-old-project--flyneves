<article class="important-content-section">
    <header>
        <h1>
            Propriedade charBreak
        </h1>
    </header>
    <p>
    O caractere que o navegador usa para quebrar linhas no campo de texto.
    </p>
    <h2 class="subtitles-main">
        <span>
            Detalhe
        </span>
    </h2>
    <p>
        Esta é uma propriedade somente leitura, ou seja, seu valor não deve ser alterado.
    </p>
    <h2 class="subtitles-main">
        <span>
            Descrição
        </span>
    </h2>
    <p>
    O “caractere de quebra de linha” são: "\r\n" ou "\n" de acordo com o navegador.
    </p>

    <h2 class="subtitles-main">
        <span>
            Syntax
        </span>
    </h2>
    <div class="code-example">
        <pre><code>
            textFieldRange( element ).charBreak;
        </code></pre>
    </div>
    <h2 class="subtitles-main">
        <span>
            Suporte a navegadores
        </span>
    </h2>
    <p>Esta propriedade possui a mesma tabela de compatibilidade da biblioteca, ou seja, basta olhar a tabela de suporte da biblioteca.</p>
</article>
