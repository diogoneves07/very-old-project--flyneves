<article class="important-content-section">
    <header>
        <h1>
        Documentação em página única
        </h1>
    </header>
    <p>
    Esta página contém toda a documentação da biblioteca controlAnimation.
    </p>
</article>
