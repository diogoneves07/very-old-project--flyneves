<div class="section-in-highlight">
        <header class="project-logo">
        <img src="<?php echo $pathToSiteDirectories->sectionDirectory; ?>controlAnimation-normal-logo-black.png" class="visible-in-light-theme" alt="controlAnimationJS - logo"/>
        <img src="<?php echo $pathToSiteDirectories->sectionDirectory; ?>controlAnimation-normal-logo-white.png" class="visible-in-dark-theme" alt="controlAnimationJS - logo"/>
        </header>
        <p>
        O simples pode ser simplesmente  incrível! Uma “cópia original”, do @keyframe CSS, mas com novas funcionalidades, leve (14.3KB), elegante, poderosa e de alto desempenho.       
        </p>
        <section class="section-in-highlight-other">
        <nav class="library-start-links">
            <ul>
            <li>
                <a href="https://www.github.com/diogoneves07/controlAnimationJS/" target="_blank">
                GitHub
                    </a>
                </li>
                <li>
                    <a href="<?php echo $pathToSiteDirectories->sectionPageDirectory; ?>documentacao/">
                        Documentação
                    </a>
                </li>
                <li>
                    <a href="<?php echo $pathToSiteDirectories->sectionPageDirectory; ?>tabela-de-suporte-a-navegadores/">
                        Suporte a navegadores
                    </a>
                </li>
            </ul>
        </nav>
        </section>
</div>
                   
                   