<article class="important-content-section">
    <header>
        <h1>
            Versões 
        </h1>
    </header>
    <p>
    Nesta página, você encontrará links para todas as versões da biblioteca controlAnimation.

    </p>
    <nav class="documentation-links">
        <ul class="normal-list">
            <li>
                <a href="1.0/">
                controlAnimation – 1.0
                </a>
            </li>
        </ul>
    </nav>
</article>
