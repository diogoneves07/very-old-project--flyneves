<?php
exit(header("location: en-US/"));
?>